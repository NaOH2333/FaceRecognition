// pages/login/index.js
var app = getApp();

const API = require('../../public/api')
// 调用封装好的时间和经纬度方法
const util = require('../../utils/util.js')

Page({
  /**
   * 页面的初始数据
   */
  data: {
    // success: false, 
    username:"  -",
    description:"  -",
    city:"  -",
    count:"  -",
    face_id:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
    this.getPosition();
  },
  // 页面离开时要清空定时器，不要再扫码人脸了
  onUnload(){
    clearInterval(this.timer);
  },

  // 获取经纬度
  getPosition(){
    let that = this;
    wx.getLocation({
      type: 'wgs84',
      success(res) {
       
        const latitude = res.latitude
        const longitude = res.longitude
        wx.request({
          url: 'https://api.map.baidu.com/geocoder/v2/?ak=aGhW5HTCoRlP1ZDMPhGaGbrGiMCpSj4a&location=' + latitude + ',' + longitude + '&output=json',
          data: {},
          header: {
            'Content-Type': 'application/json'
          },
          success: function (res) {
            // success  
            console.log(res);
            // that.setData({ city: res.data.result.addressComponent.city });
            // 存储定位信息
            app.globalData.userInfo.city = res.data.result.addressComponent.city;
            app.globalData.userInfo.thisCity = res.data.result.addressComponent.city;
            // 开启定时器，每隔5秒钟，扫码人脸，验证
            that.takePhoto();
            that.timer = setInterval(() => {
              //TODO 定时拍照
              that.takePhoto();
            }, 5000)

          },
          fail: function () {
            wx.showToast({
              title: '定位失败，无法使用本应用',
              icon: 'error',
              duration: 1000 // 持续的时间
            })
          },
          
        })
        
      },
      fail:function(){
        wx.showModal({
          title: 'GPS无法使用',
          content: '请开启GPS后，点击确定重启应用',
          success: function (res) {
             if (res.cancel) {
                // 点击取消,默认隐藏弹框
             } else {
                // 点击确定
                that.onLoad();
             }
          },
          fail: function (res) { }, // 接口调用失败的回调函数
          complete: function (res) { }, // 接口调用结束的回调函数（调用成功、失败都会执行）
       })
      },complete:function(){
        
      }
    })

  },

  /**
   * 用户打卡 
   * 在此获取用户授权，获得用户照片 发送接口进行比对结果
   */
  takePhoto: function () {
    const ctx = wx.createCameraContext()
    ctx.takePhoto({
      quality: 'normal',
      success: (res) => {
        this.setData({
          imgUrl: res.tempImagePath
        })
        // 把图片转成base64
        let base64 = wx.getFileSystemManager().readFileSync(res.tempImagePath, 'base64')
        // 进行验证
        this.requestapi(base64);
      }
    })
  },
  

  /**
   * 请求接口百度AI接口 比对接口
   */
  requestapi: function (base64) {
    let that = this;
    wx.request({
      url: API.search+wx.getStorageSync("access_token"),
      header: {
        "content-type": "application/json"
      },
      timeout: 3000,
      method: "POST",
      data: {
        image: base64,
        image_type: "BASE64",
        group_id_list: 1
      },
      success: function (res) {
        console.log(res)
        if (res.data.error_code === 0 && res.data.result) {
          if (res.data.result.user_list[0].score > 80) {

            // 记录用户信息
            app.globalData.userInfo.face_id = res.data.result.user_list[0].user_id;
            app.globalData.userInfo.city = res.data.result.user_list[0].user_info.city;
            // clearInterval(that.timer)
            // 成功跳到成功
            //wx.redirectTo({
            //  url: '/pages/msg/success?type=login'
            //})
            
            let userinfo = JSON.parse(res.data.result.user_list[0].user_info);
            that.setData({
              city: userinfo.city,
              face_id:app.globalData.userInfo.face_id
            })

            // 更新用户次数
            that.updateCount(app.globalData.userInfo.face_id);

          }else{
            that.requestapiadd(base64);
             that.setData({
               username: "尚未设定姓名",
               city: app.globalData.userInfo.city,
               count: "1",
               description: "尚未设定备注",
             })
          }
        }else if(res.data.error_code ===222207){
          that.requestapiadd(base64);
          that.setData({
            username: "尚未设定姓名",
            city: app.globalData.userInfo.city,
            count: "1",
            description: "尚未设定备注",
          })
        }

      },
      fail(err) {
        console.log('接口调用失败:', err)
      },
      complete() {
        console.log('请求完成')
      }
    })
  },
  toUpdate(){
    wx.redirectTo({
      url: '/pages/form/index',
    })
  },
  requestapiadd: function (base64) {
    let that = this;
    let userid = new Date().getTime();
    app.globalData.userInfo.face_id = userid;
    wx.request({
      url: API.add+wx.getStorageSync("access_token"),
      header: {
        "content-type": "application/json"
      },
      timeout: 3000,
      method: "POST",
      data: {
        image: base64,
        image_type: "BASE64",
        group_id: 1,
        user_id: userid,
        user_info: JSON.stringify(app.globalData.userInfo)
      },
      success: (res) => {
        // 上传成功以后
        //wx.redirectTo({
        //  url: '/pages/msg/success?type=regist'
       // })
       wx.request({
        //自己的服务器地址
        url: API.userInfo+"/add",
        timeout: 3000,
        method: "GET",
        data: {
          face_id: userid,
          city:app.globalData.userInfo.thisCity,
          count:1
        },
        success: function (res) {
          console.log(res);
          wx.showToast({
            title: '新用户录入成功',
          })
        }
      });
      },
      fail(err) {
        console.log('接口调用失败:', err)
        wx.showToast({
          title: '录入失败，请检查网络',
        })
      },
      complete() {
        console.log('请求完成')
      }
    })
  },
  updateCount(user_id){
    let that = this;
    wx.request({
      //自己的服务器地址
      url: API.userInfo+"/count",
      timeout: 3000,
      method: "GET",
      data: {
        face_id: user_id
      },
      success: function (res) {
        console.log(res.data);
        that.setData({
          username:res.data.data.userName,
          description:res.data.data.description,
          city:res.data.data.city,
          count:res.data.data.count
        });
      }
    });
  },
  failTip() {
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.autoplay = true
    innerAudioContext.src = '../../public/audio/login_fail.mp3'
    innerAudioContext.onPlay(() => {
      console.log('开始播放')
    })
    innerAudioContext.onError((res) => {
      console.log(res.errMsg)
      console.log(res.errCode)
    })
  },
  // 计算距离上班还有多长时间
  calculatRemainTime() {
    let remain_time = util.calculatRemainTime()
    this.setData({
      remain_time: remain_time
    })
  },
  onShareAppMessage(){
    return {
      title: '人脸识别',
      path: '/page/login/index'
    }
  }
})