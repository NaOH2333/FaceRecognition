const API = require("../../public/api");

const app = getApp()
// pages/form/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userName: '',
    description: '',
    city:'',
    errTip: false
  },
  
  // 获得用户名
  getUserName(e) {
    this.setData({
      userName: e.detail.value 
    })
  },
  // 获得备注
  getDescription(e) {
    this.setData({
      description: e.detail.value
    })
  },
  // 姓名和备注，不为空则跳转下一页
  nextStep() {
    let userName = this.data.userName;
    let description = this.data.description;
    if (!userName || !description) {
      this.setData({
        errTip: true
      })
    } else {
      this.sendInfo();
    }
  },
  sendInfo(){
      app.globalData.userInfo.userName = this.data.userName;
      app.globalData.userInfo.description = this.data.description;
      wx.request({
        // 自己的服务器地址
        url: API.userInfo+"/update",
        header: {
          "content-type": "application/json"
        },
        timeout: 3000,
        method: "GET",
        data: {
          userName: app.globalData.userInfo.userName,
          description: app.globalData.userInfo.description,
          face_id: app.globalData.userInfo.face_id
        },
        success: function (res) {
          wx.showToast({
            title: '修改成功',
            complete:function(){
              wx.redirectTo({
                url: '/pages/login/index',
              })
            }
          })
          
        }
      });
  },
  onShareAppMessage(){
    return {
      title: '用户信息注册',
      path: '/page/form/index'
    }
  }
})