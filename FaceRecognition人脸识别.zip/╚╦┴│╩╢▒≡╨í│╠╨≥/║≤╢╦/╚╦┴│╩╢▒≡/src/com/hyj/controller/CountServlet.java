package com.hyj.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.hyj.bean.Result;
import com.hyj.bean.User;
import com.hyj.service.UserService;

/**Servlet implementation class CountServlet 
 * 刷脸次数：每完成一次刷脸，就更新对应face_id的刷脸次数
 */
@WebServlet("/v1/user/count")
public class CountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public CountServlet() {}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ①接收参数并封装参数
		String face_id = request.getParameter("face_id");
		// ②将封装好的参数传给Service, 在数据库存储
		User user = UserService.count(face_id);

		// ③根据存储的结果返回不同的响应
		Result result = null;
		if (user != null)
			result = new Result(user, 0, "更新刷脸次数成功！");
		else
			result = new Result(-1, "更新刷脸次数失败！");
		// ④json格式转换, 响应返回给小程序
		String json = result.toString();
		response.getWriter().append(json);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
