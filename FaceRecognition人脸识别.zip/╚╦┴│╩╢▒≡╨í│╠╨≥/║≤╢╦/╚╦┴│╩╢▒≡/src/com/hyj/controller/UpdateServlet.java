package com.hyj.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.hyj.bean.Result;
import com.hyj.bean.User;
import com.hyj.service.UserService;

/**Servlet implementation class UpdateServlet
 * 更新人脸信息：更新指定用户的姓名、备注 
 */
@WebServlet("/v1/user/update")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateServlet() {}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ①接收参数并封装参数
		String face_id = request.getParameter("face_id");
		String userName = request.getParameter("userName");
		String description = request.getParameter("description");
		User user = new User();
		user.setFace_id(face_id);
		user.setUserName(userName);
		user.setDescription(description);
		// ②将封装好的参数传给Service, 在数据库存储
		int rowCount = UserService.updateUserByFaceId(face_id, user);

		// ③根据存储的结果返回不同的响应
		Result result = null;
		if (rowCount > 0)
			result = new Result(0, "更新人脸信息成功！");
		else
			result = new Result(-1, "更新人脸信息失败！");
		// ④json格式转换, 响应返回给小程序
		String json = result.toString();
		response.getWriter().append(json);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
