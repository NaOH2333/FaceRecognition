package com.hyj.service;

import com.hyj.bean.User;
import com.hyj.dao.IUserDao;
import com.hyj.dao.UserDao;

/**
 * @Description 供外部(APP层)使用的api，用户进行的一些列操作
 * @author hyjstart何永建 Email:heyongjian2333@163.com
 */
public class UserService {
	private static IUserDao dao = new UserDao();
	/**用于新增用户人脸信息
	 * 	@return 新增的结果，大于0表示成功
	 */
	public static int add(User user) {
		return dao.add(user);
	}
	/**基于人脸识别码，进行用户次数增加 <br>
	 * 新增后的全部用户信息
	 */
	public static User count(String face_id) {
		return dao.count(face_id);
	}
	
	
	/**通过face_id, 修改用户信息和备注 <br>
	 * 大于0标识成功
	 */
	public static int updateUserByFaceId(String face_id, User user) {
		return dao.updateUserByFaceId(face_id, user);
	}
	
	/**通过face_id 查询相关人脸信息
	 */
	public static User findUserByFaceId(String face_id) {
		return dao.findUserByFaceId(face_id);
	}
}
