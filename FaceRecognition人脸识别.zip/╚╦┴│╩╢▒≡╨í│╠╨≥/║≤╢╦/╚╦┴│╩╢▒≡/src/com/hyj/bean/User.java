package com.hyj.bean;

/**
 * @Description User用户类: 用于存储人脸相关信息
 * @author hyjstart何永建 Email:heyongjian2333@163.com
 * @version 1.0
 */
public class User {
	private int id; // 用户标识id, 数据库中为主键
	private String face_id; // 人脸标识
	private String userName; // 用户姓名
	private String description; // 用户备注(描述)
	private String city; // 首次录入城市 
	private int count; // 已录入次数 
	// 时间戳：格林威治历1970-1-1 0到现在的时间差(java为毫秒数)
	private long lastTime; // 用户上一次刷脸时间
	// 无参和全参构造器
	public User() {
	}
	public User(int id, String face_id, String userName, String description, String city, int count, long lastTime) {
		this.id = id;
		this.face_id = face_id;
		this.userName = userName;
		this.description = description;
		this.city = city;
		this.count = count;
		this.lastTime = lastTime;
	}
	// getter和setter 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFace_id() {
		return face_id;
	}
	public void setFace_id(String face_id) {
		this.face_id = face_id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public long getLastTime() {
		return lastTime;
	}
	public void setLastTime(long lastTime) {
		this.lastTime = lastTime;
	}
	// toString() equals() Hashcode()
	@Override
	public String toString() {
		return "User [id=" + id + ", face_id=" + face_id + ", userName=" + userName + ", description=" + description
				+ ", city=" + city + ", count=" + count + ", lastTime=" + lastTime + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + count;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((face_id == null) ? 0 : face_id.hashCode());
		result = prime * result + id;
		result = prime * result + (int) (lastTime ^ (lastTime >>> 32));
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		User other = (User) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city)) return false;
		if (count != other.count) return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (face_id == null) {
			if (other.face_id != null)
				return false;
		} else if (!face_id.equals(other.face_id))
			return false;
		if (id != other.id)
			return false;
		if (lastTime != other.lastTime)
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}
	
}
