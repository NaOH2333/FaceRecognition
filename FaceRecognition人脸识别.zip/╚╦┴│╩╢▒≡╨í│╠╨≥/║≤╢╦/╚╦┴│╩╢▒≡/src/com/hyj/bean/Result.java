package com.hyj.bean;

//import com.alibaba.fastjson.JSON;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**@Description Result结果类: 用于描述小程序"操作的响应结果"
 * @author hyjstart何永建 Email:heyongjian2333@163.com
 */
public class Result {
    public static final Gson gson= new GsonBuilder().create();
	private Object data; // 用户User对象
	private int status; // 操作成功与否标识
	private String message; // 操作结果说明 
	// 构造器
	public Result() {}
	public Result(int status) {
		this.status = status;
	}
	public Result(int status, String message) {
		this.status = status;
		this.message = message;
	}
	public Result(Object data, int status, String message) {
		this.data = data;
		this.status = status;
		this.message = message;
	}
	// getter和setter toString
	@Override
	public String toString() {
        return gson.toJson(this);
//        return JSON.toJSONString(this);
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
