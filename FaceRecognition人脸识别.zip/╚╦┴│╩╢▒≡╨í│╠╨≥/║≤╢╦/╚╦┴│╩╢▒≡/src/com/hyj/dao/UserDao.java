package com.hyj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.hyj.bean.User;
import com.hyj.util.DatabaseUtil;

/**
 * @Description 与数据库(PolarDB云数据库)链接，对数据库进行操作<br>
 * 注意：尽可能晚地链接数据库，尽可能早地释放数据库
 * @author hyjstart何永建 Email:heyongjian2333@163.com
 */
public class UserDao implements IUserDao {
	private static final String SQL_INSERT = "INSERT INTO user_list(face_id,city,lasttime) VALUES(?,?,?)";
	private static final String SQL_UPDATE_USER_BY_FACEID = "UPDATE user_list set username=?,description=? WHERE face_id=?";
	private static final String SQL_UPDATE_COUNT_BY_FACEID = "UPDATE user_list set count=?,lasttime=? WHERE face_id=?";;
	private static final String SQL_FIND_USER_BY_FACEID = "SELECT * FROM user_list WHERE face_id=?";
	private int time = 60 *1000; // 每1分钟录入人脸数据，可更改
	
	public void setTime(int time) {
		this.time = time;
	}
	public int getTime() {
		return time;
	}

	/** 添加新的人脸数据: 人脸标识 城市 时间
	 */
	@Override
	public int add(User user) {
		// 1.链接数据库 及预编译执行的SQL环境
		Connection connection = DatabaseUtil.getConn();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(SQL_INSERT);
			// 2.填充预编译的参数
			statement.setString(1, user.getFace_id());
			statement.setString(2, user.getCity());
			statement.setLong(3, System.currentTimeMillis());
			// 3.执行存储：
//			int rowCount = statement.executeUpdate(); // (更新)影响的行数
			return statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 4.释放链接
			DatabaseUtil.close(connection, statement, null);
		}
		return -1;
	}
	/**根据face_id 看是否刷新人脸数据(刷脸次数)
	 */
	@Override
	public User count(String face_id) {
		// 1.查询信息
		User user = findUserByFaceId(face_id);
		// 每隔一段时间收录人脸数据(默认1分钟，可更改)
		if ((System.currentTimeMillis() - user.getLastTime()) > time) {
			// 修改次数
			user.setCount(user.getCount() + 1);
			updateCountByFaceId(face_id, user.getCount());
		}
		return user;
	}
	
	/**根据face_id, 修改对应人脸的姓名/备注
	 */
	@Override
	public int updateUserByFaceId(String face_id, User user) {
		Connection connection = DatabaseUtil.getConn();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(SQL_UPDATE_USER_BY_FACEID);
			statement.setString(1, user.getUserName());
			statement.setString(2, user.getDescription());
			statement.setString(3, face_id);
			return statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtil.close(connection, statement, null);
		}
		return -1;
	}

	@Override
	public int updateCountByFaceId(String face_id, int count) {
		Connection connection = DatabaseUtil.getConn();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(SQL_UPDATE_COUNT_BY_FACEID);
			statement.setInt(1, count);
			statement.setLong(2, System.currentTimeMillis());
			statement.setString(3, face_id);
			return statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtil.close(connection, statement, null);
		}
		return -1;
	}
	
	/**根据face_id查看人脸数据(所有信息)
	 */
	@Override
	public User findUserByFaceId(String face_id) {
		Connection connection = DatabaseUtil.getConn();
		PreparedStatement statement = null;
		ResultSet rs = null; // 1.用于"查询"
		try {
			statement = connection.prepareStatement(SQL_FIND_USER_BY_FACEID);
			statement.setString(1, face_id);
			// 2.执行查询！
			rs = statement.executeQuery();
			if (rs.next()) {
				int id = rs.getInt("id");
				String userName = rs.getString("userName");
				String description = rs.getString("description");
				String city = rs.getString("city");
				int count = rs.getInt("count");
				long lastTime = rs.getLong("lastTime");
				return new User(id, face_id, userName, description, city, count, lastTime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 3.*查询*：释放链接！
			DatabaseUtil.close(connection, statement, rs);
		}
		return null;
	}

}
