package com.hyj.dao;

import com.hyj.bean.User;

/**
 * @Description 用于操作数据库的API
 * @author hyjstart何永建 Email:heyongjian2333@163.com
 * @version 1.0
 */
public interface IUserDao {
	/** 增
	 * @Description 添加人脸数据
	 * @author hyjstart何永建 Email:heyongjian2333@163.com
	 * 	@param user
	 * 	@return 大于0表示成功
	 */
	int add(User user);
	/**
	 * @Description 基于人脸标识，看是否更新刷脸次数
	 * @author hyjstart何永建 Email:heyongjian2333@163.com
	 * 	@param face_id
	 * 	@return 更新后的人脸数据
	 */
	User count(String face_id);
	// 删
//	int delete(int id);
	// 改
	/**
	 * @Description 根据face_id, 修改用户的姓名/备注
	 * @author hyjstart何永建 Email:heyongjian2333@163.com
	 * 	@param face_id
	 * 	@param user
	 * 	@return 大于0成功
	 */
	int updateUserByFaceId(String face_id, User user);
	/**
	 * @Description 根据face_id 增加相应刷脸次数
	 * @author hyjstart何永建 Email:heyongjian2333@163.com
	 * 	@param face_id count
	 * 	@return 修改后，大于0成功
	 */
	int updateCountByFaceId(String face_id, int count);
	
	/**查
	 * @Description 根据face_id 查询用户信息
	 * @author hyjstart何永建 Email:heyongjian2333@163.com
	 * 	@param face_id
	 * 	@return 所查询的用户所有信息
	 */
	User findUserByFaceId(String face_id); 
}
