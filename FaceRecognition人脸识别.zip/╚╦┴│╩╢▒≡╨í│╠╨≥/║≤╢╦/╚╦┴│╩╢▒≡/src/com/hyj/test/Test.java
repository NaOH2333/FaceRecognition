package com.hyj.test;

import java.sql.Connection;
import com.hyj.bean.User;
import com.hyj.service.UserService;
import com.hyj.util.DatabaseUtil;

/**@Description 测试类：测试相关功能是否正常
 * @author hyjstart何永建 Email:heyongjian2333@163.com
 */
public class Test {
	public static void main(String[] args) {
		// 1测试能否与数据库链接
		Connection connection = DatabaseUtil.getConn();
		
		// 1.①测试add()添加人脸数据
		User user1 = new User();
		user1.setFace_id("123456");
		user1.setCity("成都");
		UserService.add(user1);
		UserService.count("123456");
		// 1.②修改制定face_id的人脸数据(姓名/备注)
//		User user2 = new User();
//		user2.setFace_id("123");
//		user2.setCity("南充");
//		user2.setUserName("贾伟");
//		user2.setDescription("草莓种猪憨憨怪");
//		UserService.add(user2);
//		UserService.updateUserByFaceId("123", user2);
		
		// 1.③查询
//		UserService.findUserByFaceId("123");
	}
}
